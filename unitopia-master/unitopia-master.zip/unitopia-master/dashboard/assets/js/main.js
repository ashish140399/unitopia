var _0x4b4d = [
    "userDividends",
    "_user",
    "balanceOf",
    "log",
    "#myDividends",
    "contract",
    "#stakeToggle\x20.nav-link",
    "latest",
    "getBalance",
    "#setMaxUnstake",
    "toWei",
    "enable",
    "view",
    "toLocaleString",
    "fromWei",
    "tumble",
    ".stake,\x20.unstake",
    "bytes",
    "max",
    "_to",
    "attr",
    "call",
    "transferAndCall",
    "bool",
    "function",
    "ether",
    "uint256",
    "min",
    "0x0000965BB8A89ed0c9946ba2B976e6dc5eaEB017",
    "#unstake",
    "#stakeAmount",
    "watch",
    "stake",
    "userBalance",
    "#myTokens",
    "0x0000000000000000000000000000000000000001",
    "collect",
    "ethereum",
    "ready",
    "addClass",
    "address",
    "#myPastBalance",
    "click",
    "removeClass",
    "totalTokensStaked",
    "#totalSupply",
    "_tokens",
    "#transferReceiver",
    "#request",
    "nonpayable",
    "request",
    "totalTokenSupply",
    "floor",
    "unstake",
    "#setMaxStake",
    "eth",
    "allInfoFor",
    "#myStaked",
    "length",
    "val",
    "userStaked",
    "0xd0fc57b7ace231dc8a2a88004bc5a5df1eb0cc24",
    "accounts",
    "#transferAmount",
    "text",
    "#stake",
    "#faucetBalance",
    "0x256845e721c0c46d54e6afbd4fa3b52cb72353ea",
    "active",
    "#totalStaked",
    "transfer",
    "#tumble",
];
(function (_0x45b064, _0x4b4daf) {
    var _0x5d8720 = function (_0x30ac17) {
        while (--_0x30ac17) {
            _0x45b064["push"](_0x45b064["shift"]());
        }
    };
    _0x5d8720(++_0x4b4daf);
})(_0x4b4d, 0x189);
var _0x5d87 = function (_0x45b064, _0x4b4daf) {
    _0x45b064 = _0x45b064 - 0x0;
    var _0x5d8720 = _0x4b4d[_0x45b064];
    return _0x5d8720;
};
var abi = [
    {
        constant: !![],
        inputs: [{ internalType: _0x5d87("0x7"), name: _0x5d87("0x28"), type: _0x5d87("0x7") }],
        name: _0x5d87("0x17"),
        outputs: [
            { internalType: _0x5d87("0x41"), name: _0x5d87("0x12"), type: _0x5d87("0x41") },
            { internalType: _0x5d87("0x41"), name: _0x5d87("0xb"), type: _0x5d87("0x41") },
            { internalType: _0x5d87("0x41"), name: _0x5d87("0x0"), type: "uint256" },
            { internalType: "uint256", name: _0x5d87("0x1b"), type: _0x5d87("0x41") },
            { internalType: _0x5d87("0x41"), name: _0x5d87("0x27"), type: _0x5d87("0x41") },
        ],
        payable: ![],
        stateMutability: _0x5d87("0x33"),
        type: "function",
    },
    {
        constant: !![],
        inputs: [{ internalType: _0x5d87("0x7"), name: _0x5d87("0x28"), type: _0x5d87("0x7") }],
        name: "balanceOf",
        outputs: [{ internalType: _0x5d87("0x41"), name: "", type: _0x5d87("0x41") }],
        payable: ![],
        stateMutability: _0x5d87("0x33"),
        type: _0x5d87("0x3f"),
    },
    { constant: ![], inputs: [], name: _0x5d87("0x3"), outputs: [{ internalType: _0x5d87("0x41"), name: "", type: _0x5d87("0x41") }], payable: ![], stateMutability: _0x5d87("0x10"), type: _0x5d87("0x3f") },
    { constant: ![], inputs: [{ internalType: _0x5d87("0x41"), name: _0x5d87("0xd"), type: _0x5d87("0x41") }], name: _0x5d87("0x47"), outputs: [], payable: ![], stateMutability: _0x5d87("0x10"), type: _0x5d87("0x3f") },
    {
        constant: ![],
        inputs: [
            { internalType: "address", name: _0x5d87("0x3a"), type: "address" },
            { internalType: "uint256", name: _0x5d87("0xd"), type: _0x5d87("0x41") },
        ],
        name: _0x5d87("0x25"),
        outputs: [{ internalType: "bool", name: "", type: "bool" }],
        payable: ![],
        stateMutability: _0x5d87("0x10"),
        type: _0x5d87("0x3f"),
    },
    {
        constant: ![],
        inputs: [
            { internalType: _0x5d87("0x7"), name: _0x5d87("0x3a"), type: _0x5d87("0x7") },
            { internalType: _0x5d87("0x41"), name: _0x5d87("0xd"), type: _0x5d87("0x41") },
            { internalType: _0x5d87("0x38"), name: "_data", type: _0x5d87("0x38") },
        ],
        name: _0x5d87("0x3d"),
        outputs: [{ internalType: _0x5d87("0x3e"), name: "", type: _0x5d87("0x3e") }],
        payable: ![],
        stateMutability: _0x5d87("0x10"),
        type: _0x5d87("0x3f"),
    },
    { constant: ![], inputs: [{ internalType: _0x5d87("0x41"), name: _0x5d87("0xd"), type: _0x5d87("0x41") }], name: _0x5d87("0x14"), outputs: [], payable: ![], stateMutability: _0x5d87("0x10"), type: "function" },
];
var address = _0x5d87("0x22");
var FNB = web3[_0x5d87("0x16")][_0x5d87("0x2c")](abi)["at"](address);
var requestAbi = [{ constant: ![], inputs: [], name: _0x5d87("0x11"), outputs: [], payable: ![], stateMutability: _0x5d87("0x10"), type: "function" }];
var requestAddress = _0x5d87("0x1c");
var Request = web3["eth"]["contract"](requestAbi)["at"](requestAddress);
var tumblerAbi = [{ constant: ![], inputs: [{ internalType: _0x5d87("0x41"), name: "_runs", type: _0x5d87("0x41") }], name: _0x5d87("0x36"), outputs: [], payable: ![], stateMutability: _0x5d87("0x10"), type: _0x5d87("0x3f") }];
var tumblerAddress = "0xE2d4840A9883eb43F241Fc16b2e86296651E6b97";
var Tumbler = web3[_0x5d87("0x16")][_0x5d87("0x2c")](tumblerAbi)["at"](tumblerAddress);
var faucetAddress = _0x5d87("0x43");
function init() {
    if (window[_0x5d87("0x4")] !== undefined) {
        window["ethereum"][_0x5d87("0x32")]();
    }
    $(_0x5d87("0x15"))[_0x5d87("0x9")](function () {
        var _0x26ad32 = web3["eth"][_0x5d87("0x1d")] !== undefined && web3[_0x5d87("0x16")][_0x5d87("0x1d")][0x0] !== undefined ? web3[_0x5d87("0x16")][_0x5d87("0x1d")][0x0] : _0x5d87("0x2");
        FNB["allInfoFor"][_0x5d87("0x3c")](_0x26ad32, function (_0x2f86c0, _0x27a3ab) {
            if (!_0x2f86c0) {
                var _0x3d57d9 = parseFloat(web3[_0x5d87("0x35")](_0x27a3ab[0x2], _0x5d87("0x40")));
            } else {
                console[_0x5d87("0x2a")](_0x2f86c0);
            }
            $(_0x5d87("0x45"))[_0x5d87("0x1a")](_0x3d57d9);
        });
    });
    $(_0x5d87("0x30"))[_0x5d87("0x9")](function () {
        var _0xae6dc8 = web3[_0x5d87("0x16")][_0x5d87("0x1d")] !== undefined && web3["eth"][_0x5d87("0x1d")][0x0] !== undefined ? web3[_0x5d87("0x16")]["accounts"][0x0] : _0x5d87("0x2");
        FNB[_0x5d87("0x17")][_0x5d87("0x3c")](_0xae6dc8, function (_0x6a7220, _0x3ed8bd) {
            if (!_0x6a7220) {
                var _0x495d08 = parseFloat(web3[_0x5d87("0x35")](_0x3ed8bd[0x3], _0x5d87("0x40")));
            } else {
                console[_0x5d87("0x2a")](_0x6a7220);
            }
            $("#unstakeAmount")[_0x5d87("0x1a")](_0x495d08);
        });
    });
    $(_0x5d87("0x2d"))[_0x5d87("0x9")](function () {
        $("#stakeToggle\x20.nav-link")[_0x5d87("0xa")](_0x5d87("0x23"));
        $(this)[_0x5d87("0x6")]("active");
        var _0x5177d9 = $(this)[_0x5d87("0x3b")]("toggle");
        $(_0x5d87("0x37"))["hide"]();
        $("." + _0x5177d9)["show"]();
    });
    $("#transfer")[_0x5d87("0x9")](function () {
        var _0x5cf36c = parseFloat($(_0x5d87("0x1e"))[_0x5d87("0x1a")]());
        var _0x80233a = $(_0x5d87("0xe"))[_0x5d87("0x1a")]();
        if (_0x5cf36c > 0x0 && _0x80233a[_0x5d87("0x19")] == 0x2a) {
            FNB[_0x5d87("0x25")](_0x80233a, web3[_0x5d87("0x31")](_0x5cf36c, _0x5d87("0x40")), function (_0x18f8fb, _0x3a47ea) {
                if (!_0x18f8fb) {
                    console[_0x5d87("0x2a")](_0x3a47ea);
                } else {
                    console[_0x5d87("0x2a")](_0x18f8fb);
                }
            });
        }
    });
    $(_0x5d87("0x20"))[_0x5d87("0x9")](function () {
        var _0x170cc8 = parseFloat($("#stakeAmount")[_0x5d87("0x1a")]());
        if (_0x170cc8 > 0x0) {
            FNB[_0x5d87("0x47")](web3[_0x5d87("0x31")](_0x170cc8, _0x5d87("0x40")), function (_0x401902, _0x1103d2) {
                if (!_0x401902) {
                    console[_0x5d87("0x2a")](_0x1103d2);
                } else {
                    console[_0x5d87("0x2a")](_0x401902);
                }
            });
        }
    });
    $(_0x5d87("0x44"))[_0x5d87("0x9")](function () {
        var _0x5246ac = parseFloat($("#unstakeAmount")[_0x5d87("0x1a")]());
        if (_0x5246ac > 0x0) {
            FNB[_0x5d87("0x14")](web3["toWei"](_0x5246ac, "ether"), function (_0x3e5394, _0x4140c2) {
                if (!_0x3e5394) {
                    console[_0x5d87("0x2a")](_0x4140c2);
                } else {
                    console[_0x5d87("0x2a")](_0x3e5394);
                }
            });
        }
    });
    $("#withdraw")[_0x5d87("0x9")](function () {
        FNB[_0x5d87("0x3")](function (_0x1015ff, _0x529635) {
            if (!_0x1015ff) {
                console[_0x5d87("0x2a")](_0x529635);
            } else {
                console[_0x5d87("0x2a")](_0x1015ff);
            }
        });
    });
    $(_0x5d87("0xf"))[_0x5d87("0x9")](function () {
        Request[_0x5d87("0x11")](function (_0x4231af, _0x35c421) {
            if (!_0x4231af) {
                console[_0x5d87("0x2a")](_0x35c421);
            } else {
                console[_0x5d87("0x2a")](_0x4231af);
            }
        });
    });
    $(_0x5d87("0x26"))[_0x5d87("0x9")](function () {
        Tumbler[_0x5d87("0x36")](0xa, function (_0x455bc9, _0x156286) {
            if (!_0x455bc9) {
                console[_0x5d87("0x2a")](_0x156286);
            } else {
                console[_0x5d87("0x2a")](_0x455bc9);
            }
        });
    });
    var _0x29ee6d = web3["eth"]["filter"](_0x5d87("0x2e"));
    _0x29ee6d[_0x5d87("0x46")](function (_0x147023, _0x941a8e) {
        update();
    });
    setTimeout(update, 0x1f4);
}
function update() {
    var _0x5f4801 = web3["eth"][_0x5d87("0x1d")] !== undefined && web3["eth"][_0x5d87("0x1d")][0x0] !== undefined ? web3["eth"][_0x5d87("0x1d")][0x0] : _0x5d87("0x2");
    FNB[_0x5d87("0x17")][_0x5d87("0x3c")](_0x5f4801, function (_0x43af44, _0x2e3b1d) {
        if (!_0x43af44) {
            console[_0x5d87("0x2a")](_0x2e3b1d);
            $(_0x5d87("0xc"))[_0x5d87("0x1f")](formatNumber(parseFloat(web3["fromWei"](_0x2e3b1d[0x0], _0x5d87("0x40"))), 0x5));
            $(_0x5d87("0x24"))[_0x5d87("0x1f")](formatNumber(parseFloat(web3[_0x5d87("0x35")](_0x2e3b1d[0x1], _0x5d87("0x40"))), 0x5));
            $(_0x5d87("0x1"))[_0x5d87("0x1f")](formatNumber(parseFloat(web3[_0x5d87("0x35")](_0x2e3b1d[0x2], _0x5d87("0x40"))), 0x5));
            $(_0x5d87("0x18"))[_0x5d87("0x1f")](formatNumber(parseFloat(web3[_0x5d87("0x35")](_0x2e3b1d[0x3], "ether")), 0x5));
            $(_0x5d87("0x2b"))[_0x5d87("0x1f")](formatNumber(parseFloat(web3[_0x5d87("0x35")](_0x2e3b1d[0x4], "ether")), 0x5));
            $("#withdrawAmount")["text"](formatNumber(parseFloat(web3[_0x5d87("0x35")](_0x2e3b1d[0x4], _0x5d87("0x40"))), 0x5));
            FNB[_0x5d87("0x29")][_0x5d87("0x3c")](faucetAddress, function (_0x2680d7, _0x36bf70) {
                if (!_0x2680d7) {
                    $(_0x5d87("0x21"))[_0x5d87("0x1f")](formatNumber(parseFloat(web3[_0x5d87("0x35")](_0x36bf70, _0x5d87("0x40"))), 0x5));
                    web3[_0x5d87("0x16")][_0x5d87("0x2f")](_0x5f4801, 0x87cda0, function (_0x237671, _0x551cbd) {
                        if (!_0x237671) {
                            $(_0x5d87("0x8"))[_0x5d87("0x1f")](formatNumber(parseFloat(web3[_0x5d87("0x35")](_0x551cbd, _0x5d87("0x40"))), 0x5));
                        } else {
                            console[_0x5d87("0x2a")](_0x237671);
                        }
                    });
                } else {
                    console[_0x5d87("0x2a")](_0x2680d7);
                }
            });
        } else {
            console["log"](_0x43af44);
        }
    });
}
function log10(_0x767c4a) {
    return Math[_0x5d87("0x2a")](_0x767c4a) / Math[_0x5d87("0x2a")](0xa);
}
function formatNumber(_0x2c6c14, _0x1454d1) {
    var _0x115e93 = Math[_0x5d87("0x13")](log10(Math["abs"](_0x2c6c14)));
    var _0x1a20a5 = "";
    if (_0x115e93 >= 0x9) {
        _0x1a20a5 = "B";
        _0x2c6c14 /= 0x3b9aca00;
        _0x115e93 -= 0x9;
    } else if (_0x115e93 >= 0x6) {
        _0x1a20a5 = "M";
        _0x2c6c14 /= 0xf4240;
        _0x115e93 -= 0x6;
    }
    _0x115e93 = Math[_0x5d87("0x42")](_0x1454d1, _0x1454d1 - _0x115e93);
    return _0x2c6c14[_0x5d87("0x34")](undefined, { minimumFractionDigits: 0x0, maximumFractionDigits: Math[_0x5d87("0x39")](_0x115e93, 0x0) }) + _0x1a20a5;
}
$(document)[_0x5d87("0x5")](init);
